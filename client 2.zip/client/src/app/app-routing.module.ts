import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './views/home/home.component';
import { PageNotFoundComponent } from './views/page-not-found/page-not-found.component';
import { MetricDetailsComponent } from './views/metric-details/metric-details.component';
import { EmployeeDetailsComponent } from './views/employee-details/employee-details.component';

const routes: Routes = [
  { path: '', component:  HomeComponent, pathMatch: 'full'},
  { path: 'home', component:  HomeComponent},
  { path: 'metric-details/:title/:below/:meets/:exceeds/:overall/:updown', component: MetricDetailsComponent},
  { path: 'employee-details/:attuid/:name', component: EmployeeDetailsComponent},
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
