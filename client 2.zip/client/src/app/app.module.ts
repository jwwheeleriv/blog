import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './views/header/header.component';
import { MainNavBarComponent } from './components/main-nav-bar/main-nav-bar.component';
import { LeftSideNavComponent } from './components/left-side-nav/left-side-nav.component';
import { SubNavBarComponent } from './components/sub-nav-bar/sub-nav-bar.component';
import { HomeComponent } from './views/home/home.component';
import { MetricsComponent } from './components/metrics/metrics.component';
import { InsightsComponent } from './components/insights/insights.component';
import { PageNotFoundComponent } from './views/page-not-found/page-not-found.component';
import { ChartsModule } from 'ng2-charts';
import { DonutComponent } from './components/charts/donut/donut.component';
import { MetricDetailsComponent } from './views/metric-details/metric-details.component';
import { EmployeeDetailsComponent } from './views/employee-details/employee-details.component';
import { EsriMapComponent } from './components/esri-map/esri-map.component';
import { WorkLoadComponent } from './components/work-load/work-load.component';
import { DonutLoadComponent } from './components/charts/donut-load/donut-load.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MainNavBarComponent,
    LeftSideNavComponent,
    SubNavBarComponent,
    HomeComponent,
    MetricsComponent,
    InsightsComponent,
    PageNotFoundComponent,
    DonutComponent,
    MetricDetailsComponent,
    EmployeeDetailsComponent,
    EsriMapComponent,
    WorkLoadComponent,
    DonutLoadComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ChartsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
