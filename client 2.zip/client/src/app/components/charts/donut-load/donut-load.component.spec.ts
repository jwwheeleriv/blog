import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonutLoadComponent } from './donut-load.component';

describe('DonutLoadComponent', () => {
  let component: DonutLoadComponent;
  let fixture: ComponentFixture<DonutLoadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonutLoadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonutLoadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
