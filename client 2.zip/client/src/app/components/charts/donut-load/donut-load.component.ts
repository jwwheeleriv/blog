import { Component, OnInit } from '@angular/core';
import { ChartType } from 'chart.js';
import { MultiDataSet, Label, PluginServiceGlobalRegistrationAndOptions } from 'ng2-charts';

@Component({
  selector: 'app-donut-load',
  templateUrl: './donut-load.component.html',
  styleUrls: ['./donut-load.component.scss']
})
export class DonutLoadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  // Doughnut
  public doughnutChartLabels: Label[] = [' Installs',' Repairs',' Chronics', ' Repeats', ' Completed'];
  public doughnutChartData: MultiDataSet = [[15,25,3,5,10]];
  public chartColors: any[] = [{ 
    backgroundColor:['#3e95cd','#8e5ea2','#3cba9f','#c45850','#ffc30b']
  }];
  public doughnutChartOptions: object = {
    legend: {position:'bottom'},
    responsive: true,
    cutoutPercentage: 65,
     
  }
  public doughnutChartType: ChartType = 'doughnut';

}
