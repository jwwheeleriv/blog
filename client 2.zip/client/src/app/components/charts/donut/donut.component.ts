import { Component, OnInit,  Input, ViewChild } from '@angular/core';
import { ChartType } from 'chart.js';
import { MultiDataSet, Label, PluginServiceGlobalRegistrationAndOptions } from 'ng2-charts';
import { Router } from '@angular/router';
@Component({
  selector: 'app-donut',
  templateUrl: './donut.component.html',
  styleUrls: ['./donut.component.scss']
})
export class DonutComponent implements OnInit {

  @Input() title: string; 
  @Input() below: number; 
  @Input() meets: number; 
  @Input() exceeds: number; 
  @Input() overall: string; 
  @Input() updown: string;
  @Input() showDetails: boolean = true;

  private ds: number[]=[];

   // Doughnut
   public doughnutChartLabels: Label[] = [' Below',' Meets',' Exceeds'];
   public doughnutChartData: MultiDataSet;
   public doughnutChartOptions: object = {
      responsive: true,
      cutoutPercentage: 75
   }
   public doughnutChartType: ChartType = 'doughnut';
   public chartColors: any[] = [{ 
      backgroundColor:["#dc3545", "#ffc107", "#28a745" ] 
    }];
  
    public doughnutChartPlugins: PluginServiceGlobalRegistrationAndOptions[] = [{
      
      afterDraw(chart) {
        const ctx = chart.ctx;
        
        //Get options from the center object in options
        const sidePadding = 60;
        //const sidePaddingCalculated = (sidePadding / 100) * (chart.innerRadius * 2)
  
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
        const centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
  
        //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
        //const stringWidth = ctx.measureText(txt).width;
        //const elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;
  
        // Find out how much the font can grow in width.
        //const widthRatio = elementWidth / stringWidth;
        //const newFontSize = Math.floor(30 * widthRatio);
        //const elementHeight = (chart.innerRadius * 2);
  
        // Pick a new font size so it will not be larger than the height of label.
        //const fontSizeToUse = Math.min(newFontSize);//, elementHeight);
  
        ctx.font = '16px Arial';
        ctx.fillStyle = 'grey';
    
        // Draw text in center
        ctx.fillText('%', centerX, centerY);
        
      }
    }];
  constructor(
    private route: Router
  ) {}

  ngOnInit() {
    this.ds.push(this.below);
    this.ds.push(this.meets);
    this.ds.push(this.exceeds);
    this.doughnutChartData = <[]>this.ds;
    
  }

  // events
  public chartClicked(e: any): void {
    console.log(this.ds, this.title, this.overall, this.updown);
    this.route.navigate(['/metric-details', this.title, this.below, this.meets, this.exceeds, this.overall, this.updown]);
  }

  public chartHovered({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }

}
