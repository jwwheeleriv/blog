import { Component, OnInit, ViewChild, ElementRef, Input, Output, EventEmitter } from '@angular/core';
import { loadModules } from 'esri-loader';
import esri = __esri; // Esri TypeScript Types

@Component({
  selector: 'app-esri-map',
  templateUrl: './esri-map.component.html',
  styleUrls: ['./esri-map.component.scss']
})
export class EsriMapComponent implements OnInit {

  @Output() mapLoadedEvent = new EventEmitter<boolean>();

  // The <div> where we will place the map
  @ViewChild('mapViewNode') private mapViewEl: ElementRef;

  /**
   * _zoom sets map zoom
   * _center sets map center
   * _basemap sets type of map
   * _loaded provides map loaded status
   */
  private _zoom = 10;
  private _center: Array<number> = [0.1278, 51.5074];
  private _basemap = 'streets';
  private _loaded = false;


  get mapLoaded(): boolean {
    return this._loaded;
  }

  @Input()
  set zoom(zoom: number) {
    this._zoom = zoom;
  }

  get zoom(): number {
    return this._zoom;
  }

  @Input()
  set center(center: Array<number>) {
    this._center = center;
  }

  get center(): Array<number> {
    return this._center;
  }

  @Input()
  set basemap(basemap: string) {
    this._basemap = basemap;
  }

  get basemap(): string {
    return this._basemap;
  }

  constructor() { }

  async initializeMap() {
    try {

      const options = {
        url: 'https://localhost/assets/arcgis_js_api/library/4.13/init.js'
      };

      // Load the modules for the ArcGIS API for JavaScript
      const [esriConfig, esriMapView, webMap, widgetLegend, widgetLayerList, widgetPopup] = await loadModules([
        'esri/config',
        'esri/views/MapView',
        'esri/WebMap',
        "esri/widgets/Legend",
        "esri/widgets/LayerList",
        "esri/widgets/Popup"
      ], options);

      // Configure the Map
      const mapProperties: esri.MapProperties = {
        basemap: this._basemap,

      };

      // Layer.fromPortalItem({
      //   portalItem: {
      //     id: "e691172598f04ea8881cd2a4adaa45ba",
      //     // autocastable to Portal
      //     portal: {
      //       url: "https://thePortalUrl"
      //     }
      //   }
      // });

      // const portalA = new Portal({
      //   url: "https://www.exampleA.com/arcgis" 
      // });
      
      // let item = new PortalItem({
      //   id: "e691172598f04ea8881cd2a4adaa45ba",
      //   portal: portalA // This loads the first portal instance set above
      // });
      
      // item.load();

      esriConfig.portalUrl = "https://l1rta.web.att.com/rapid_gis";

      var webmap = new webMap({
        portalItem: { // autocasts as new PortalItem()
          id: "7a32ee02e72549d0a95ac55d2d3fbce5"
        }
      });

      
      // const map: esri.Map = new EsriMap(mapProperties);

      // // Initialize the MapView
      // const mapViewProperties: esri.MapViewProperties = {
      //   container: this.mapViewEl.nativeElement,
      //   center: this._center,
      //   zoom: this._zoom,
      //   map: map
      // };

      // return new EsriMapView(mapViewProperties);
     // webmap.load();
      let view = new esriMapView({
        map: webmap,  // The WebMap instance created above
        container: this.mapViewEl.nativeElement,
      });

      view.when(function() {
        // get the first layer in the collection of operational layers in the WebMap
        // when the resources in the MapView have loaded.
        var featureLayer = webmap.layers.getItemAt(0);

        var legend = new widgetLegend({
          view: view,
          layerInfos: [
            {
              layer: featureLayer,
              title: "LKL"
            }
          ]
        });

        var layerList = new widgetLayerList({
          view: view
        });
        // Adds widget below other elements in the top left corner of the view
        view.ui.add(layerList, {
          position: "top-left"
        });
        // Add widget to the bottom right corner of the view
        view.ui.add(legend, "bottom-right");
      });
    
      return view;

    } catch (error) {
      console.log('EsriLoader: ', error);
    }

  }

  // Finalize a few things once the MapView has been loaded
  houseKeeping(mapView) {
    mapView.when(() => {
      console.log('mapView ready: ', mapView.ready);
      this._loaded = mapView.ready;
      this.mapLoadedEvent.emit(true);
    });
  }

  ngOnInit() {
    // Initialize MapView and return an instance of MapView
    this.initializeMap().then((mapView) => {
      this.houseKeeping(mapView);
    });
  }

}