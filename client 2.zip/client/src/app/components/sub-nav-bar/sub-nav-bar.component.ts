import { Component, OnInit, Input } from '@angular/core';
import { Location } from '@angular/common';
@Component({
  selector: 'app-sub-nav-bar',
  templateUrl: './sub-nav-bar.component.html',
  styleUrls: ['./sub-nav-bar.component.scss']
})
export class SubNavBarComponent implements OnInit {

  @Input() type: string;
  @Input() title: string;
  
  public greeting: string;

  constructor(
    private location: Location
  ) { }

  ngOnInit() {
    this.greeting = this.getGreeting();
  }

  getGreeting() {
      const date = new Date();
      const hours = date.getHours();
      if (hours < 12) {
        return 'Good Morning ';
      } else if (hours >= 12 && hours < 17) {
        return 'Good Afternoon ';
      } else {
        return 'Good Evening ';
      }

  }

  navBack(){
    this.location.back();
  }

}
