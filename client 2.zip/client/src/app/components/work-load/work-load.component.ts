import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work-load',
  templateUrl: './work-load.component.html',
  styleUrls: ['./work-load.component.scss']
})
export class WorkLoadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
