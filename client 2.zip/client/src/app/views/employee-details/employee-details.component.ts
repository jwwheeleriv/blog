import { Component, OnInit, Input} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.scss']
})
export class EmployeeDetailsComponent implements OnInit {

  employeeName: string = "John Doe";
  employeeATTUID: string = '';

  constructor(
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.employeeATTUID = this.route.snapshot.paramMap.get("attuid");
    this.employeeName = this.route.snapshot.paramMap.get("name");
  }

}
