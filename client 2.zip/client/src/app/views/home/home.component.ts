import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  public showSection: string = 'dashboard'

  // Set our map properties
  mapCenter = [-122.4194, 37.7749];
  basemapType = 'streets';
  mapZoomLevel = 12;

  constructor() { }

  ngOnInit() {
  }

  changeSection(section){
    this.showSection = section;
  }

  mapLoadedEvent(status: boolean) {
    console.log('The map loaded: ' + status);
  }
}
