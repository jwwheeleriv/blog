import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-metric-details',
  templateUrl: './metric-details.component.html',
  styleUrls: ['./metric-details.component.scss']
})
export class MetricDetailsComponent implements OnInit {

  title: string = '';
  below: number;
  meets: number;
  exceeds: number;
  overall: string = '';
  updown: string = '';

  constructor(
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.title = this.route.snapshot.paramMap.get("title");
    this.below = parseFloat(this.route.snapshot.paramMap.get("below"));
    this.meets = parseFloat(this.route.snapshot.paramMap.get("meets"));
    this.exceeds = parseFloat(this.route.snapshot.paramMap.get("exceeds"));
    this.overall = this.route.snapshot.paramMap.get("overall");
    this.updown = this.route.snapshot.paramMap.get("updown");
  }

}
